const requiredKeys = ['title', 'year', 'genre', 'director', 'rate'];

export { requiredKeys };